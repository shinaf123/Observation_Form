// import 'package:flutter/material.dart';
// import 'package:obsarvation_form/provider/get_apicall.dart';
// import 'package:obsarvation_form/view/home.dart';
// import 'package:provider/provider.dart';

// class MainProvider extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return ChangeNotifierProvider(
//       create: (context) => ObservationFormProvider(),
//       child: const HomePage(),
//     );
//   }
// }