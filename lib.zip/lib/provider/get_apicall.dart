// import 'dart:convert';
// import 'dart:developer';

// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;

// class ObservationFormProvider extends ChangeNotifier {
//   List<Map<String, dynamic>> _projects = [];
//   List<Map<String, dynamic>> get projects => _projects;

//   List<Map<String, dynamic>> _projectDescriptions = [];
//   List<Map<String, dynamic>> get projectDescriptions => _projectDescriptions;

//   getProject() async {
//     try {
//       final response = await http.get(
//           Uri.parse('http://103.120.178.195/Sang.Ray.Mob.Api/Ray/GetProject'));

//       if (response.statusCode == 200) {
//         Map<String, dynamic> respo = jsonDecode(response.body);
//         _projects = jsonDecode(respo['ResultData']);
//         log(response.body.toString());
//         notifyListeners();
//       } else {
//         print('Failed to load data. Status code: ${response.statusCode}');
//       }
//     } catch (error) {
//       print('Error in getProject: $error');
//     }
//   }

//   getProjectDescription() async {
//     try {
//       final response = await http.get(Uri.parse(
//           'http://103.120.178.195/Sang.Ray.Mob.Api/Ray/GetProjectDescription?iProject=2'));
//       if (response.statusCode == 200) {
//         Map<String, dynamic> resp = jsonDecode(response.body);
//         List<dynamic> resultData = jsonDecode(resp["ResultData"]);
//         _projectDescriptions = resultData as List<Map<String, dynamic>>;

//         log(resultData.toString());
//         log(response.body.toString());

//         notifyListeners();

//       } else {
//         print('Failed to load data. Status code: ${response.statusCode}');
//       }
//     } catch (e) {
//       print('Error in getProjectDescription: $e');
//     }
//   }
// }
