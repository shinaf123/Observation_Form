import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:http/http.dart' as http;
part 'getprojectname_event.dart';
part 'getprojectname_state.dart';

class GetprojectnameBloc extends Bloc<GetprojectnameEvent, GetprojectnameState> {
  GetprojectnameBloc() : super(GetprojectnameInitial()) {
    on<GetprojectnameEvent>((event, emit) async {

      
    });
  }
}
