part of 'getprojectname_bloc.dart';

@immutable
sealed class GetprojectnameState {}



final class GetprojectnameInitial extends GetprojectnameState {}

