part of 'getprojectname_bloc.dart';

@immutable
sealed class GetprojectnameEvent {}

