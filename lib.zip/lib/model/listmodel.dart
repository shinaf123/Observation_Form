

class ListModel {
    String? observation;
    String? riskLevel;
    String? actionReq;
    String? actionBy;
    String targetDate;
    final images;

    ListModel({
        required this.observation,
        required this.riskLevel,
        required this.actionReq,
        required this.actionBy,
        required this.targetDate,
        required this.images,
    });

   
}

